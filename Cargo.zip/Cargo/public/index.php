<?php





   
    $_SESSION['user_data'] = $_POST;
    $fichier=[
        "air",
        "maritine",
        "route",
     
        ];
    
       if(isset($_GET["page"])){
    
        $page=$_GET["page"];
          if(in_array($page,$fichier)){
               include("../templates/layout.html.php");
                 require_once '../templates/'.$page.'.html.php';
            }else{
             
               }








//    }else{

//     if(isset($_POST["page"])){
   
//         $page=$_POST["page"];
//         if($page=="filter"){

//                 include("../templates/layout.html.php");
//                 require_once '../templates/'.$page.'.html.php';
//     } else if($page=="search"){
            
//           include("../templates/layout.html.php");
//           require_once '../templates/'.$page.'.html.php';
//           }else if($page=="filter2"){
            
//           include("../templates/layout.html.php");
//           require_once '../templates/'.$page.'.html.php';
//           }
//        }


//        if($_POST["status"]=="salut"){
//         $presents=$students;
//        }
     
   
    
    //amadousy343@gmaol.com lettre ,otive
   }

?>

<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<a href="?page=air" >air</a>
<a href="?page=maritine">maritine</a>
<a href="?page=route">route</a>
</body>
</html> -->

<!--  -->
<!-- <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestion des Envois de Colis</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
  <div class="container mx-auto mt-10">
    <div class="lg:flex shadow-md my-10">
      <div class="w-3/4 bg-white px-10 py-10">
        <div class="flex justify-between border-b pb-8">
          <h1 class="font-semibold text-2xl">Gestion des Envois</h1>
          <h1 class="font-semibold text-2xl" id="article-count">0 Colis</h1>
        </div>
        <div class="flex mt-10 mb-5">
          <h3 class="font-bold text-gray-600 text-xs uppercase w-2/5">Détails du Colis</h3>
          <h3 class="font-bold text-center text-xs uppercase w-1/5 mx-8">Quantité</h3>
          <h3 class="font-bold text-center text-xs uppercase w-1/5 mx-8">Prix/Unité</h3>
          <h3 class="font-bold text-center text-xs uppercase w-1/5">Total</h3>
          <h3 class="font-bold text-center text-xs uppercase w-1/5">Transport</h3>
        </div>
        <div id="product-list"></div>
      </div>

      <div class="w-1/4 px-8 py-10 -mt-40 justify-between">
        <h1 class="font-semibold text-2xl borderb pb-8 text-orange-400">-50%</h1>
        <div class="flex justify-between mt-10 mb-5">
          <span class="font-semibold text-sm uppercase">Total</span>
          <span class="font-semibold text-sm uppercase" id="total-price">0 Francs</span>
        </div>
        <div>
          <label class="font-medium inline-block mb-3 text-sm uppercase">Type de Cargaison</label>
          <select id="transport-type" class="block p-2 text-gray-600 w-full text-sm">
            <option value="route">Route</option>
            <option value="avion">Avion</option>
            <option value="air">Air</option>
          </select>
        </div>
        <div class="py-10">
          <label class="font-semibold inline-block mb-3 text-sm uppercase"></label>
          <input type="text" placeholder="Entrez votre code" class="p-2 text-sm w-full">
        </div>
        <button class="bg-red-500 hover:bg-red-600 px-5 py-2 text-sm text-white uppercase" onclick="applyTransport()">Appliquer</button>
        <div class="border-t mt-8">
          <div class="flex font-semibold justify-between py-6 text-sm uppercase">
            <span>Prix Total</span>
            <span id="final-price">0 Francs</span>
          </div>
          <button class="bg-indigo-500 font-semibold hover:bg-indigo-600 py-3 text-sm text-white uppercase lg:w-full">Confirmer</button>
        </div>
      </div>
    </div>
  </div>

  <script>
    document.addEventListener('DOMContentLoaded', function () {
      // Test data
      const testData = [
        {
          title: 'Colis 1',
          category: 'Electronics',
          quantity: 2,
          price: 50,
          transportType: 'route'
        },
        {
          title: 'Colis 2',
          category: 'Clothing',
          quantity: 1,
          price: 30,
          transportType: 'avion'
        },
        {
          title: 'Colis 3',
          category: 'Books',
          quantity: 3,
          price: 20,
          transportType: 'route'
        }
      ];

      // Load test data into localStorage if it doesn't exist
      if (!localStorage.getItem('card')) {
        localStorage.setItem('card', JSON.stringify(testData));
      }

      const card = JSON.parse(localStorage.getItem('card')) || [];
      const productList = document.getElementById('product-list');
      const articleCount = document.getElementById('article-count');
      const totalPrice = document.getElementById('total-price');
      const finalPrice = document.getElementById('final-price');
      const transportTypeSelect = document.getElementById('transport-type');

      function updateTotal() {
        const total = card.reduce((acc, item) => {
          let itemTotal = item.price * item.quantity;
          if (item.transportType === 'air') {
            itemTotal *= 1.2; // Exemple de majoration pour le transport par air
          }
          return acc + itemTotal;
        }, 0);
        totalPrice.textContent = `${total} Francs`;
        finalPrice.textContent = `${total} Francs`;
        articleCount.textContent = `${card.length} Colis`;
      }

      function renderProducts() {
        productList.innerHTML = '';
        card.forEach((colis, index) => {
          const productDiv = document.createElement('div');
          productDiv.className = 'flex items-center hover:bg-gray-100 -mx-8 px-6 py-5';
          productDiv.innerHTML = `
            <div class="flex w-2/5">
              <span>${colis.title}</span>
              <div class="flex flex-col justify-between ml-4 flex-grow">
                <span class="text-gray-500 text-sm">${colis.category}</span>
                <div class="font-bold hover:text-gray-500 text-red-500 text-xs">
                  <button onclick="handleRemove(${index})">Supprimer</button><br>
                </div>
              </div>
            </div>
            <div class="flex justify-center w-1/12 mx-24">
              <button onclick="handleDecrease(${index})" class="font-extrabold border-solid bg-blue-200 text-2xl">-</button>
              <input class="border text-center w-8 mx-2" type="text" value="${colis.quantity}" readonly>
              <button onclick="handleIncrease(${index})" class="font-extrabold border-solid bg-blue-200 text-2xl">+</button>
            </div>
            <span class="text-center w-1/5 font-semibold text-sm">${colis.price}</span>
            <span class="text-center w-1/5 font-semibold text-sm">${colis.price * colis.quantity}</span>
            <span class="text-center w-1/5 font-semibold text-sm">${colis.transportType}</span>
          `;
          productList.appendChild(productDiv);
        });
      }

      window.applyTransport = function() {
        const selectedTransport = transportTypeSelect.value;
        card.forEach((colis) => {
          colis.transportType = selectedTransport;
        });
        localStorage.setItem('card', JSON.stringify(card));
        renderProducts();
        updateTotal();
      }

      window.handleIncrease = function(index) {
        card[index].quantity += 1;
        localStorage.setItem('card', JSON.stringify(card));
        renderProducts();
        updateTotal();
      }

      window.handleDecrease = function(index) {
        if (card[index].quantity > 1) {
          card[index].quantity -= 1;
          localStorage.setItem('card', JSON.stringify(card));
          renderProducts();
          updateTotal();
        }
      }

      window.handleRemove = function(index) {
        card.splice(index, 1);
        localStorage.setItem('card', JSON.stringify(card));
        renderProducts();
        updateTotal();
      }

      renderProducts();
      updateTotal();
    });
  </script>
</body>
</html> -->
