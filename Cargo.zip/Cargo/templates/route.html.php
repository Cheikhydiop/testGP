<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Gestion des Envois de Colis</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>

<body class="bg--100">
<button class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" id="openModalButton">Ouvrir le Modal</button>
  <!-- Barre de navigation -->
  <nav class="bg-[#374151] py-4">
    <div class="container mx-auto mr-20 flex justify-between items-center">
      <h1 class="text-white text-2xl font-semibold">Gestion des Envois de Colis</h1>
      <ul class="flex space-x-4 text-white text-lg font-medium">
        <li><a href="#" class="hover:underline">Accueil</a></li>
        <li><a href="#creer-cargaison" class="hover:underline">Créer une Cargaison</a></li>
        <li><a href="#rechercher-colis" class="hover:underline">Rechercher un Colis</a></li>
      </ul>
    </div>
  </nav>

  <!-- Contenu principal -->
  <div class="container mx-auto py-10 mr-20 ">
    <!-- Section Créer une Cargaison -->
    <section id="creer-cargaison" class="my-8">
      <h2 class="text-2xl font-semibold mb-4 ">Créer une Cargaison</h2>
      <form class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <!-- Champs du formulaire -->
        <!-- Exemple : Numéro de Cargaison -->
        <div class="mb-4">
          <label for="numero" class="block text-sm font-medium text-gray-700">Numéro de Cargaison</label>
          <input type="text" id="numero" name="numero" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
        </div>
        <!-- Autres champs du formulaire -->
        <!-- Ajoutez ici les autres champs comme poids max, produits, trajet, etc. -->

        <!-- Bouton de soumission -->
        <div class="flex items-center justify-between">
          <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Créer</button>
        </div>
      </form>
    </section>

    <!-- Section Rechercher un Colis -->
    <section id="rechercher-colis" class="my-8">
      <h2 class="text-2xl font-semibold mb-4">Rechercher un Colis</h2>
      <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
        <!-- Barre de recherche -->
        <div class="mb-4">
          <label for="search" class="block text-sm font-medium text-gray-700">Rechercher par Code</label>
          <input type="text" id="search" name="search" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
        </div>
        <!-- Liste des résultats de recherche -->
        <div class="overflow-x-auto">
          <!-- Utilisez des cartes ou des éléments de liste pour afficher les résultats -->
          <!-- Exemple de carte pour un colis -->
          <div class="bg-gray-100 rounded-lg p-4 mb-4">
            <h3 class="text-lg font-semibold">Colis 12345</h3>
            <p class="text-sm text-gray-700">Poids: 10 kg | Produits: Electronics | Transport: Route</p>
            <!-- Autres informations sur le colis -->
          </div>
        </div>
      </div>
    </section>
  </div>


  <!-- Pied de page -->
  <!-- <footer class="bg-gray-200 py-4 mt-10">
    <div class="container mx-auto text-center text-gray-600 text-sm">
      &copy; 2024 Gestion des Envois de Colis. Tous droits réservés.
    </div>
  </footer> -->
  <!-- Overlay -->
<div class="fixed top-0 left-0 w-full h-full bg-gray-800 bg-opacity-50 flex items-center justify-center z-50 hidden" id="modalOverlay">
  <!-- Modal -->
  <div class="bg-white p-8 rounded-lg shadow-xl w-96" id="modalContent">
    <h2 class="text-xl font-bold mb-4">Ajouter un élément</h2>
    <label for="nom" class="block mb-2">Nom :</label>
    <input type="text" id="nom" class="w-full border border-gray-300 rounded px-3 py-2 mb-4 focus:outline-none focus:border-blue-500">
    <label for="description" class="block mb-2">Description :</label>
    <textarea id="description" class="w-full border border-gray-300 rounded px-3 py-2 mb-4 focus:outline-none focus:border-blue-500"></textarea>
    <button class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Ajouter</button>
    <button class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline ml-2" id="modalClose">Annuler</button>
  </div>
</div>

  <script>

    // Sélectionner les éléments du modal
const modalOverlay = document.getElementById('modalOverlay');
const modalContent = document.getElementById('modalContent');
const modalClose = document.getElementById('modalClose');

// Afficher le modal
function openModal() {
  modalOverlay.classList.remove('hidden');
}

// Cacher le modal
function closeModal() {
  modalOverlay.classList.add('hidden');
}

// Écouter les événements pour ouvrir/fermer le modal
modalClose.addEventListener('click', closeModal);

// Vous pouvez déclencher l'ouverture du modal où vous en avez besoin, par exemple :
// openModal();

  </script>
</body>

</html>
